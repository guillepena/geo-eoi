import numpy as np

import matplotlib.pyplot as plt, matplotlib.patches as mpatches

from skimage import io, exposure

import pandas as pd

from sklearn.cluster import KMeans

from sklearn.ensemble import RandomForestClassifier

import os

# ------------
#
# Reads an image, filtering nulls in the process.
#
# ------------
def read_image(name):

  image = io.imread(name)

  image[image == -999.0] = np.nan

  return image

# ------------
#
# Uses matplotlib to show an image.
#
# ------------
def matplotlib_show_image(image, colors="Greys", figsize=(20,10),
  savefile=None):

  # Le indica a matplotlib que cree un nuevo contexto de imagen con tamaño 20x20 cm
  plt.figure(figsize=figsize)

  # Indica que sobre el contexto actual se muestre la imagen blue, es decir, los valores de reflectancia de
  # la única banda de la imagen cargada cmap indica qué esquema de colores se quiere utilizar en la representación
  plt.imshow(image, cmap=colors)

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", image)

  # Indica al contexto que genere una banda de referencia de color al lado de la imagen
  plt.colorbar()

# ------------
#
# Uses matplotlib to show the histogram of an image.
#
# ------------
def matplotlib_show_image_histogram(image, bins=500, histtype="step",
  range=(0.0, 1.0), figsize=(20,10), savefile=None):

  plt.figure(figsize=figsize)

  # Histograma de frecuencias con 500 pasos
  plt.hist(image.ravel(), bins=bins, histtype=histtype, range=range)

  # Save if savefile
  if (savefile):
    plt.savefig(savefile)

# ------------
#
# Uses matplotlib to show an equalized image.
#
# ------------
def matplotlib_show_eq_image(image, clip_limit=0.025, colors="Greys",
  figsize=(20,10), savefile=None):

  # Ecualización por histograma adaptativa sobre los valores de la imagen
  image_eq = exposure.equalize_adapthist(image, clip_limit=clip_limit)

  plt.figure(figsize=figsize)

  plt.imshow(image_eq, cmap=colors)

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", image_eq)

# ------------
#
# Uses matplotlib to compare an image with its equalized version side by side.
#
# ------------
def matplotlib_compare_eq_images(image, clip_limit=0.025, colors="Greys",
  figsize=(20,20), savefile=None):

  # Ecualización por histograma adaptativa sobre los valores de la imagen
  image_eq = exposure.equalize_adapthist(image, clip_limit=clip_limit)

  img = np.hstack([image, image_eq])

  plt.figure(figsize=figsize)

  plt.imshow(img, cmap=colors)

  # Save if savefile
  if (savefile):
    plt.savefig(savefile)

# ------------
#
# Creates a Numpy stack of images.
#
# ------------
def stack_images(savefile, *images):

  images_stack = []

  for i in images:
    images_stack.append(read_image(i))

  scene = np.stack(images_stack, axis=2)

  np.save(savefile, scene);

  return scene

# ------------
#
# Uses matplotlib for visualizing false color images.
#
# ------------
def matplotlib_false_color(scene, red_band, green_band, blue_band,
  savefile=None, figsize=(20,10), clip_limit=0.025):

  true_color = scene[:, :, (red_band, green_band, blue_band)]

  true_color_eq = exposure.equalize_adapthist(true_color, clip_limit=clip_limit)

  plt.figure(figsize=figsize)

  plt.imshow(true_color_eq)

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", true_color)

# ------------
#
# Calculates the NDVI of an image.
#
# ------------
def ndvi(scene, nir_band, red_band):

  return (scene[:,:,nir_band] - scene[:,:,red_band]) / \
    (scene[:,:,nir_band] + scene[:,:,red_band])

# ------------
#
# Uses matplotlib to plot NDVI values.
#
# ------------
def matplotlib_show_ndvi(ndvi_data, figsize=(20,10), savefile=None,
  colors="RdBu"):

  plt.figure(figsize=figsize)

  plt.imshow(ndvi_data, cmap=colors, vmin=-1, vmax=1)

  plt.colorbar()

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", ndvi_data)

# ------------
#
# Uses matplotlib to plot NDVI positive values.
#
# ------------
def matplotlib_show_ndvi_positive(ndvi_data, figsize=(20,10), savefile=None,
  colors="Greens"):

  ndvi_pos = np.copy(ndvi_data)

  # Filtramos con un selector los valores por debajo de 0
  # y los ponemos a nan
  ndvi_pos[ ndvi_pos < 0.0 ] = np.nan

  plt.figure(figsize=figsize)

  plt.imshow(ndvi_pos, cmap=colors, vmin=0, vmax=1)

  plt.colorbar()

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", ndvi_pos)

# ------------
#
# Uses matplotlib to plot NDVI negative values.
#
# ------------
def matplotlib_show_ndvi_negative(ndvi_data, figsize=(20,10), savefile=None,
  colors="Greens"):

  ndvi_neg = np.copy(ndvi_data)

  # Filtramos con un selector los valores por debajo de 0
  # y los ponemos a nan
  ndvi_neg[ ndvi_neg > 0.0 ] = np.nan

  plt.figure(figsize=figsize)

  plt.imshow(ndvi_neg, cmap=colors, vmin=-1, vmax=0)

  plt.colorbar()

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", ndvi_neg)

# ------------
#
# Vectorized function to clasify NDVI.
#
# ------------
def ndvi_reclassify(ndvi):

  # Y lo categoriza en función de lo anteriormente mencionado
  if ndvi<=0:                         # Agua
      return float(0.0)

  if ndvi>0 and ndvi<=0.2:            # NDVI urbano y suelos desnudos
      return float(1.0)

  elif ndvi>0.2 and ndvi<=0.5:        # NDVI vegetación rala
      return float(2.0)

  elif ndvi>0.5:                      # NDVI vegetación vigorosa
      return float(3.0)

  # Finalmente, los valores nulos deben seguir siéndolo
  return np.nan

# ------------
#
# Reclassify NDVI in categories.
#
# ------------
def reclassify_ndvi(ndvi_data):

  # Vectorizamos la función anterior
  reclasificacion_ndvi = np.vectorize(ndvi_reclassify)

  # Reclasificamos el NDVI con la función anterior
  clasificacion = reclasificacion_ndvi(ndvi_data)

  return clasificacion

# ------------
#
# Uses matplotlib to plot NDVI negative values.
#
# ------------
def matplotlib_show_ndvi_classes(ndvi_data, savefile=None, figsize=(20,10)):
  plt.figure(figsize=figsize)

  # Extracción de cuatro categorías de color con un mapa de colores discretos
  # (ya no es una gama continua)
  cmap = plt.cm.get_cmap('Set3', 4)

  # Visualizamos con el mapa obtenido
  plt.imshow(ndvi_data, cmap=cmap)

  # Aquí aplicamos una leyenda especial
  # Creamos una leyenda a partir de cuatro parches de los colores generados anteriormente,
  # a los que se le asigna la categoría temática correspondiente
  plt.legend([ mpatches.Patch(color=cmap(b)) for b in range(4) ],
            [ u'Agua', u'Urbano / suelo desnudo', u'Vegetación rala', u'Vegetación vigorosa' ])

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", ndvi_data)

# ------------
#
# Generates NDVI surface stats.
#
# ------------
def ndvi_stats(ndvi_data):

  np.unique(ndvi_data)

  unique, counts = np.unique(ndvi_data, return_counts=True)

  return (counts * 30 * 30 / 1000000.0)[0:4]

# ------------
#
# Creates a K-Means clusterization on data.
#
# ------------
def k_means(scene, clusters, samples=15000):

  # Creamos un nuevo array con una banda y las dimensiones de scene inicializado a 0
  n = np.zeros(shape=(scene.shape[0], scene.shape[1], 1))

  # La reinicializamos a nan
  n[:] = np.nan

  # Acoplamos nueva capa para resultados K-Means
  scene = np.append(scene, n, axis=2)

  scene_bidim = np.resize(scene, (scene.shape[0] * scene.shape[1], 8))

  scene_bidim_no_null = scene_bidim[(~np.isnan(scene_bidim[:, :7])).any(axis=1)]

  pandas_df = pd.DataFrame(data=scene_bidim_no_null[:, :7])

  muestra = pandas_df.sample(samples)

  muestra_np = muestra.values

  kmeans = KMeans(n_clusters=clusters).fit(muestra_np)

  clusters = kmeans.predict(scene_bidim_no_null[:, :7])

  scene_bidim[~np.isnan(scene_bidim[:,:7]).any(axis=1), 7] = clusters

  return np.resize(scene_bidim, (scene.shape[0], scene.shape[1], 8))

# ------------
#
# Uses matplotlib to visualize K-Means clusters.
#
# ------------
def matplotlib_show_kmeans(scene, clusters, figsize=(20,5), color="gainsboro",
  detailmapfigsize=(100,50), savefile=None):

  # Creamos una figura múltiple para el mapa de clústers y el análisis de signaturas espectrales
  fig, (cluster_map, signatures) = plt.subplots(nrows=1, ncols=2, figsize=figsize)

  # Título de la figura
  fig.suptitle('Clusterización K')

  # Selección de la rampa de color
  cmap = plt.cm.get_cmap('Set3', clusters)


  # Etiquetas para la leyenda del mapa
  labels = [ 'Cluster %s' % i for i in range(clusters) ]

  cluster_map.legend(
    [ mpatches.Patch(color=cmap(b)) for b in range(clusters) ],
    labels
  )

  # Renderizamos el mapa
  cluster_map.imshow(scene[:,:,7], cmap=cmap)


  # Ahora creamos el diagrama de signaturas, con una línea para cada cluster
  for i in range(clusters):

    # Filtramos el cluster
    pix_grupo = scene[scene[:,:,7] == i]

    # Calculamos la media para cada banda
    group_mean = np.nanmedian(pix_grupo[:, :7], axis=0)

    # Dibujamos la signatura espectral
    signatures.plot(group_mean, color=cmap(i))

  # Leyenda para el gráfico de signaturas espectrales
  labels = [ 'Cluster %s' % i for i in range(clusters) ]

  signatures.legend(
    [ mpatches.Patch(color=cmap(b)) for b in range(clusters) ],
    labels
  )

  # Asignamos etiquetas para el eje x
  signatures.set_xticklabels(labels=[ "dd", "Ultra Blue", "Blue", "Green", "Red", "NIR", "SWIR 1", "SWIR 2" ])

  signatures.set(xlabel='Bandas', ylabel='Reflectancia normalizada',
                title='Reflectancia de los clústeres')

  # Añadimos una rejilla de referencia
  signatures.grid(color=color)

  # Mostramos y salvamos la figura
  fig.show()

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", scene[:,:,7])

# ------------
#
# Random Forest training zones.
#
# ------------
entrenamiento = [

    {

        "nombre_clase": "pantano",

        "zonas": [

            [ 967, 983, 2095, 2183 ]

        ]

    },

    {

        "nombre_clase": "oceano",

        "zonas": [

            [ 1051, 1196, 301, 654 ]

        ]

    },

    {

        "nombre_clase": "suelo / urbano",

        "zonas": [

            [ 480, 495, 554, 603 ],
            [ 686, 689, 2116, 2120 ],
            [ 262, 269, 1297, 1304 ],
            [ 177, 188, 1025, 1026 ],
            [ 631, 632, 1887, 1899 ],
            [ 412, 413, 785, 794 ],
            [ 483, 484, 514, 517 ],
            [ 491, 492, 484, 486 ]

        ]

    },

    {

        "nombre_clase": "aguas litorales",

        "zonas": [

            [ 806, 833, 558, 605 ]

        ]

    },

    {

        "nombre_clase": "vegetación vigorosa",

        "zonas": [

            [ 1106, 1120, 2162, 2180 ],
            [ 556, 573, 1093, 1106 ],
            [ 472, 475, 930, 942 ],
            [ 1071, 1081, 2017, 2029 ]

        ]

    },

    {

        "nombre_clase": "arena",

        "zonas": [

            [ 962, 966, 657, 667 ],
            [ 131, 134, 218, 222 ]

        ]

    },

    {

        "nombre_clase": "marisma",

        "zonas": [

            [ 729, 771, 713, 749 ]

        ]

    },

    {

        "nombre_clase": "vegetación rala",

        "zonas": [

            [ 484, 493, 1085, 1102 ],
            [ 521, 523, 1531, 1534 ],
            [ 899, 905, 1595, 1600 ],
            [ 979, 1002, 993, 1017 ]

        ]

    }

]

# ------------
#
# Como argumentos, la matriz de imagen y el dato de rectángulo de las zonas de
# entrenamiento anteriores.
#
# ------------
def sample_scene(scene, rect):

  # Se podría hacer con dos bucles for, pero Numpy es muy bueno haciendo slicing de matrices
  sample = scene[ rect[0]:rect[1], rect[2]:rect[3], :7 ]

  # Aplanamos la estructura filas / columnas
  sample_bidim = np.resize(sample, (sample.shape[0] * sample.shape[1], 7))

  # La transformamos en una lista Python y la devolvemos como resultado
  return sample_bidim.tolist()

# ------------
#
# Random forest.
#
# ------------
def random_forest(scene):

  n = np.zeros(shape=(scene.shape[0], scene.shape[1], 1))

  # La reinicializamos a nan
  n[:] = np.nan

  scene = np.append(scene, n, axis=2)

  samples = []

  classes = []

  # Esta variable es para designar el número de clase para la
  # clasificación: 0 > pantanos, 1 > oceano, ... , 7 > vegetación rala
  class_n = 0

  for k in entrenamiento:

    print("Procesando clase %s" % k["nombre_clase"])

    # Iteramos la lista de zonas de entrenamiento en cada clase
    for s in k["zonas"]:

        # Añadimos los vectores de entrenamiento junto a la clase
        # a la que pertenecen a la lista de píxeles de entrenamiento de
        # clase y a la lista de clase concordante

        sample = sample_scene(scene, s)
        class_s = [ class_n for i in range(len(sample)) ]

        # Añadimos ambos elementos a las listas globales de
        # entrenamiento

        samples.extend(sample)
        classes.extend(class_s)

    # Aumentamos el identificador numérico de la clase para la próxima iteración
    class_n += 1

  clf = RandomForestClassifier(n_estimators=50)

  clf.fit(samples, classes)

  scene_bidim = np.resize(scene, (scene.shape[0] * scene.shape[1], 8))

  clasificacion = \
    clf.predict(scene_bidim[~np.isnan(scene_bidim[:,:7]).any(axis=1), :7])

  scene_bidim[~np.isnan(scene_bidim[:,:7]).any(axis=1), 7] = clasificacion

  return np.resize(scene_bidim, (scene.shape[0], scene.shape[1], 8))

# ------------
#
# Uses matplotlib to display random forest results.
#
# ------------
def matplotlib_show_random_forest(scene, figsize=(20,10), savefile=None):

  plt.figure(figsize=figsize)

  cmap = plt.cm.get_cmap('Set3', 8)

  plt.imshow(scene[:,:,7], cmap=cmap)

  plt.legend(
    [ mpatches.Patch(color=cmap(b)) for b in range(8) ],
    [ u'Pantanos', u'Océano', u'Suelo / urbano', u'Aguas litorales',
      u'Vegetación vigorosa', u'Arena', u'Marismas', u'Vegetación rala' ])

  # Save if savefile
  if (savefile):
    plt.savefig(savefile + ".png")
    io.imsave(savefile + ".tif", scene[:,:,7])
